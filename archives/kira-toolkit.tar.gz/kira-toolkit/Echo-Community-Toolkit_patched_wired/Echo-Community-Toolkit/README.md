# Echo-Community-Toolkit (LSB1 + MRP Phase‑A)

This bundle includes the LSB1 encoder/decoder, the golden sample, tests, the MRP Phase‑A verifier, and a self‑sufficient `final_validation.py`.

## Quick start
```bash
python final_validation.py
```

Artifacts (if present) are under `artifacts/`.
