# Auto-generated MRP Phase A stubs — 2025-10-13T05:14:22.138385Z
# SPDX-License-Identifier: MIT

"""MRP module namespace (Phase A)
Provides stubs for headers, channels, codec, and adapters.
"""
__all__ = ["headers", "channels", "codec"]
